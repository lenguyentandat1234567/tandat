Gatling API Testing - Crash Course
============================================

Supporting source code for my [Gatling API Testing Crash Course](https://youtu.be/NzqO6AOKjeg) on YouTube:

[![Image.png](https://raw.githubusercontent.com/james-willett/gatling-api-crash-course-youtube/main/GatlingCrashCourse-2.jpg)](https://youtu.be/NzqO6AOKjeg)


https://github.com/james-willett/gatling-api-crash-course-youtube/blob/main/GatlingCrashCourse-2.jpg
